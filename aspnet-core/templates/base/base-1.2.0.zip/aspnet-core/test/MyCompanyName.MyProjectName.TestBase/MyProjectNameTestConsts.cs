﻿namespace MyCompanyName.MyProjectName;

public static class MyProjectNameTestConsts
{
    public const string CollectionDefinitionName = "MyProjectName collection";
}
