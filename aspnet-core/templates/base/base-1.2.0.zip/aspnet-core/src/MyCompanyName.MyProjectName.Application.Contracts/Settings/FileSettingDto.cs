﻿namespace MyCompanyName.MyProjectName.Settings
{
    public class FileSettingDto
    {
        public long LimitSize { get; set; }
        public long TotalLimitSize { get; set; }
        public string SupportMimeType { get; set; }
    }
}
