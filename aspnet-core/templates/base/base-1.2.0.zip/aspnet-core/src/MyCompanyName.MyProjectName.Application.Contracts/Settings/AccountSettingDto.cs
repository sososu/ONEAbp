﻿namespace MyCompanyName.MyProjectName.Settings
{
    public class AccountSettingDto
    {
        public bool IsSelfRegistrationEnabled { get; set; }
        //public bool EnableLocalLogin { get; set; }
    }
}
