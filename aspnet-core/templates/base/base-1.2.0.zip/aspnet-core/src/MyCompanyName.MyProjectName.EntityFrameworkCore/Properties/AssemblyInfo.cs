﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("ONE.Admin.EntityFrameworkCore.Tests")]
