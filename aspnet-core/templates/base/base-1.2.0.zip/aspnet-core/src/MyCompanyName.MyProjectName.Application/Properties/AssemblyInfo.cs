﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("ONE.Admin.Application.Tests")]
