﻿namespace MyCompanyName.MyProjectName
{
    public static class ExchangeTokenExtensionGrantConsts
    {
        public const string GrantType = "impersonation";
        public const string AccessToken = "access_token";
    }
}
