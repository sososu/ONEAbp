﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("ONE.Admin.Domain.Tests")]
[assembly:InternalsVisibleToAttribute("ONE.Admin.TestBase")]
