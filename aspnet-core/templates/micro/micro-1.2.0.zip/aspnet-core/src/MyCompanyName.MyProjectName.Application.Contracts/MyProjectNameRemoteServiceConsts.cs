﻿namespace MyCompanyName.MyProjectName;

public class MyProjectNameRemoteServiceConsts
{
    public const string RemoteServiceName = "MyProjectName";

    public const string ModuleName = "myProjectName";
}
