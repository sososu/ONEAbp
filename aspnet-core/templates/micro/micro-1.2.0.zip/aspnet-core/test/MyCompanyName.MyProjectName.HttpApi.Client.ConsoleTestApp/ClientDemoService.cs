﻿using System;
using System.Threading.Tasks;
using Volo.Abp.DependencyInjection;

namespace MyCompanyName.MyProjectName.HttpApi.Client.ConsoleTestApp;

public class ClientDemoService : ITransientDependency
{
    

    public ClientDemoService()
    {
        
    }

    public async Task RunAsync()
    {
       
    }
}
